window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const message = urlParams.get('message');
    const error = urlParams.get('error');

    if (message) {
        alert(message); 
    } else if (error) {
        alert('Error booking reservation: ' + error); 
    }
};
function openSidebar() {
document.getElementById('sidebar').style.width = '250px';
document.getElementById('sidebar').focus(); 
}

function closeSidebar() {
document.getElementById('sidebar').style.width = '0';
}

function validateDates() {
var checkinDate = $('#checkinDate').val();
var checkoutDate = $('#checkoutDate').val();
var validationText = $('#validationText');
if (checkinDate && checkoutDate) {
    if (new Date(checkoutDate) > new Date(checkinDate)) {
        return true;
    } else {
        validationText.show().text("Check-out date must be after check-in date.").css('color', 'red');
        return false;
    }
} else {
    validationText.show().text("Please fill in both dates.").css('color', 'red');
    return false;
}
}
$(document).ready(function() {
flatpickr("#checkinDate", {
altInput: true,
altFormat: "F j, Y",
dateFormat: "Y-m-d",
minDate: "today",
});

flatpickr("#checkoutDate", {
altInput: true,
altFormat: "F j, Y",
dateFormat: "Y-m-d",
minDate: "today",
});

$('#bookingForm').submit(function(e) {
e.preventDefault(); 
if (!validateDates()) {
    return; 
}
var checkinDate = $('#checkinDate').val();
var checkoutDate = $('#checkoutDate').val();
$('#availableRooms').html("<p>Loading available rooms...</p>");

$.ajax({
    url: 'php/get_available_rooms.php',
    type: 'POST',
    dataType: 'json',
    data: {
        checkinDate: checkinDate,
        checkoutDate: checkoutDate
    },
    success: function(rooms) {
        var content = "<h3>Select a Room</h3>";
        if (rooms.error) {
            content += "<p>" + rooms.error + "</p>";
        }
        else if (rooms.length > 0) {
        rooms.forEach(function(room, index) {
            content += `
            <div class="room-card">
                <div class="room-image">
                    <img src="images/${room.image}" alt="${room.name}" style="width:100%; height:auto; max-height:200px;">
                </div>
                <div class="room-info">
                    <h4>${room.name}</h4>
                    <p><strong>Max Guests:</strong> ${room.max_guests}</p>
                    <p><strong>Price:</strong> ${room.price} per night</p>
                    <p><strong>Description:</strong> ${room.description}</p>
                </div>
                <div class="room-select">
                    <input type="radio" name="roomChoice" id="room${room.room_id}" value="${room.room_id}" ${index === 0 ? "" : ""}>
                </div>
            </div>`;
        });
        content += `
            <button id="confirmButton" style="display:none; margin-top:20px;">Confirm Your Reservation</button>`;
        
        $('#availableRooms').show().html(content);
        $('input[name="roomChoice"]').change(function() {
            $('#confirmButton').show();
        });
    } else {
        content += "<p>No rooms available for your selected dates.</p>";
        $('#availableRooms').html(content);
    }
    }
});
});

$(document).on('click', '#confirmButton', function() {
var selectedRoom = $('input[name="roomChoice"]:checked').val();
var checkinDate = $('#checkinDate').val();
var checkoutDate = $('#checkoutDate').val();
window.open('confirm_reservation.php?room_id=' + selectedRoom + '&checkin=' + checkinDate + '&checkout=' + checkoutDate , '_blank');
});
});

function openSidebar() {
    console.log("Opening sidebar");
    document.getElementById('sidebar').style.width = '250px';
  }

  function closeSidebar() {
    console.log("Closing sidebar");
    document.getElementById('sidebar').style.width = '0';
  }

  document.addEventListener("DOMContentLoaded", function () {
    var goToTopButton = document.getElementById("go-to-top-btn");

    window.addEventListener("scroll", function () {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            goToTopButton.style.display = "block";
        } else {
            goToTopButton.style.display = "none";
        }
    });

    goToTopButton.addEventListener("click", function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    });
  });