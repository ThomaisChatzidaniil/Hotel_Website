document.addEventListener("DOMContentLoaded", function () {
  const galleryItems = [
    { src: "images/1407953244000-177513283.webp", alt: "Double Room", title: "Double Room" },
    { src: "images/9a97fc0cae887fb6954e12c40f2cd96a.jpg", alt: "Pool", title: "Pool" },
    { src: "images/double.png", alt: "Double Room", title: "Double Room" },
    { src: "images/f1a5d9597183f133f290068f07eedb94.jpg", alt: "Suite", title: "Suite" },
    { src: "images/family.jpg", alt: "Suite", title: "Suite" },
    { src: "images/main_page.jpg", alt: "Front View", title: "Front View" },
    { src: "images/main_page_2.jpg", alt: "Reception", title: "Reception" },
    { src: "images/OIP.jpeg", alt: "Reception", title: "Reception" },
    { src: "images/Room_double.jpeg", alt: "Double Room", title: "Double Room" },
    { src: "images/single.webp", alt: "Single Room", title: "Single Room" },
    { src: "images/suite.jpeg", alt: "Suite", title: "Suite" },
    { src: "images/suite2.jpeg", alt: "Double Room", title: "Double Room" },
    { src: "images/bar.jpeg", alt: "Bar", title: "Bar" },
    { src: "images/cafe.jpeg", alt: "Cafe", title: "Cafe" },
    { src: "images/div2.jpeg", alt: "Pool", title: "Pool" },
    { src: "images/double.png", alt: "Double Room", title: "Double Room" },
    { src: "images/double2.jpeg", alt: "Double Room", title: "Double Room" },
    { src: "images/double4.jpeg", alt: "Bathroom", title: "Bathroom" },
    { src: "images/double5.webp", alt: "Double Room", title: "Double Room" },
    { src: "images/double6.jpeg", alt: "Double Room", title: "Double Room" },
    { src: "images/event.jpg", alt: "Event", title: "Event" },
    { src: "images/family3.jpg", alt: "Family Suite", title: "Family Suite" },
    { src: "images/family4.jpg", alt: "Family Suite", title: "Family Suite" },
    { src: "images/family5.jpg", alt: "Family Suite", title: "Family Suite" },
    { src: "images/family6.jpeg", alt: "Family Suite", title: "Family Suite" },
    { src: "images/family7.jpeg", alt: "Bathroom", title: "Bathroom" },
    { src: "images/meeting.jpeg", alt: "Meetings", title: "Meetings" },
    { src: "images/restaurant.jpeg", alt: "Restaurant", title: "Restaurant" },
    { src: "images/restaurant_roof.jpeg", alt: "Roof Restaurant", title: "Roof Restaurant" },
    { src: "images/roof_bar.png", alt: "Roof Bar", title: "Roof Bar" },
    { src: "images/single.webp", alt: "Single Room", title: "Single Room" },
    { src: "images/single1.webp", alt: "Bathroom", title: "Bathroom" },
    { src: "images/single2.jpg", alt: "Bathroom", title: "Bathroom" },
    { src: "images/single3.jpg", alt: "Single Room", title: "Single Room" },
    { src: "images/single4.jpg", alt: "Single Room", title: "Single Room" },
    { src: "images/single5.webp", alt: "Single Room", title: "Single Room" },
    { src: "images/single6.jpeg", alt: "Single Room", title: "Single Room" },
    { src: "images/suite.jpeg", alt: "Suite", title: "Suite" },
    { src: "images/suite1.jpeg", alt: "Bathroom", title: "Bathroom" },
    { src: "images/suite2.jpeg", alt: "Suite", title: "Suite" },
    { src: "images/suite3.jpeg", alt: "Suite", title: "Suite" },
    { src: "images/suite4.jpg", alt: "Suite", title: "Suite" }

  ];
  function generateGallery() {
    const galleryContainer = document.getElementById('gallery-container');
    galleryItems.forEach(item => {
      const galleryItem = document.createElement('div');
      galleryItem.className = 'gallery-item';
      galleryItem.innerHTML = `
        <img src="${item.src}" alt="${item.alt}" tabindex="0">
        <div class="image-overlay">
        <div class="overlay-content">
            <div class="overlay-title">${item.title}</div>
        </div>
    </div>
      `;
      galleryItem.addEventListener('click', function() {
        openLightbox(item.src, item.alt, item.title);
      });
      galleryContainer.appendChild(galleryItem);
    });
  }

  generateGallery();

  function openLightbox(imageSrc, imageAlt, imageTitle) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    const lightboxDescription = document.querySelector('.lightbox-description');
  
    lightboxImage.src = imageSrc;
    lightboxImage.alt = imageAlt;
    lightboxDescription.textContent = imageTitle; 
  
    lightbox.style.display = 'flex'; 
    document.body.style.overflow = 'hidden'; 
  
    const closeBtn = document.getElementById('lightbox-close');
    closeBtn.onclick = function() {
      lightbox.style.display = 'none';
      document.body.style.overflow = ''; 
    }
  }
  

});

document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById('sidebar');
  const menuBtn = document.getElementById('menu-btn');
  const closeBtn = document.getElementById('close-btn');
  const goToTopButton = document.getElementById("go-to-top-btn");

  menuBtn.addEventListener('click', function() {
    sidebar.style.width = '250px';
  });

  closeBtn.addEventListener('click', function() {
    sidebar.style.width = '0';
  });

  window.addEventListener("scroll", function () {
    goToTopButton.style.display = (window.scrollY > 20) ? "block" : "none";
  });

  goToTopButton.addEventListener("click", function () {
    window.scrollTo({top: 0, behavior: 'smooth'});
  });
});
