gsap.from('#text-content li', {duration: 0.5, opacity: 0, y: -20, stagger: 0.2});

$(document).ready(function () {
  const galleryImages = [
      "hotel_project/images/main_page.jpg",
      "hotel_project/images/main_page_2.jpg",
      "hotel_project/images/1407953244000-177513283.webp",
      "hotel_project/images/9a97fc0cae887fb6954e12c40f2cd96a.jpg"
  ];

  let currentImageIndex = 0;

  function changeImage(step) {
      currentImageIndex = (currentImageIndex + step + galleryImages.length) % galleryImages.length;
      $('#gallery-image').attr('src', galleryImages[currentImageIndex]);
  }

  $('.gallery-arrow').on('click', function() {
      const direction = $(this).hasClass('prev') ? -1 : 1;
      changeImage(direction);
  });

  $('#menu-btn').on('click', function() {
    $('#sidebar').toggleClass('open').animate({width: '250px'}, function() {
        console.log('Sidebar toggle animation completed.');
    });
});

$('#close-btn').css({'fontSize': '24px', 'cursor': 'pointer'}).on('click', function() {
    $('#sidebar').removeClass('open').animate({width: '0'}, 350); 
});
  

  setInterval(() => changeImage(1), 10000);

  $(window).scroll(function() {
      $('#go-to-top-btn').toggle($(this).scrollTop() > 20);
  });

  $('#go-to-top-btn').on('click', function() {
      $('html, body').animate({scrollTop: 0}, '300');
  });

  let currentGalleryIndex = 0;
  const galleries = [
    {
        title: "Double Deluxe Room",
        description: "A blend of modern elegance and comfort, our Deluxe Double Room is designed for a luxurious stay. Featuring a king-size bed and stylish decor, it offers a serene retreat.",
        link: "hotel_project/double_room.html",
        images: ["hotel_project/images/double.png"]
    },
    {
        title: "Luxury Suite",
        description: "Indulge in luxury with our Suite, a haven of opulence. With a separate living area and a king-size bed, it provides an exclusive space for a lavish escape.",
        link: "hotel_project/suite.html",
        images: ["hotel_project/images/suite.jpeg", "hotel_project/images/suite2.jpg"]
    },
    {
        title: "Deluxe Single Room",
        description: "Perfect for solo travelers, our Deluxe Single Room offers a cozy retreat with a comfortable bed and modern amenities, ensuring a restful stay.",
        link: "hotel_project/single_room.html",
        images: ["hotel_project/images/single.webp"]
    },
    {
        title: "Family Suite",
        description: "Create family memories in our spacious Family Suite, designed for togetherness. With separate sleeping areas, it's an ideal choice for a comfortable and memorable family getaway.",
        link: "hotel_project/family.html",
        images: ["hotel_project/images/f1a5d9597183f133f290068f07eedb94.jpg"]
    }
];

  function changeGallery(direction) {
      currentGalleryIndex = (currentGalleryIndex + direction + galleries.length) % galleries.length;

      const currentGallery = galleries[currentGalleryIndex];
      $('#gallery-title').text(currentGallery.title);
      $('#gallery-description').text(currentGallery.description);
      $('#gallery-link').attr('href', currentGallery.link);
      $('#new_gallery-image').attr('src', currentGallery.images[0]).attr('alt', 'Gallery Image 1');
  }

  $('#prev-room-btn, #next-room-btn').click(function () {
      const direction = $(this).is('#prev-room-btn') ? -1 : 1;
      changeGallery(direction);
  });

  changeGallery(0);
  setInterval(() => changeGallery(1), 10000);
});
