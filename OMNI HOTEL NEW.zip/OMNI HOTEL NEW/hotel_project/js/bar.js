function openSidebar() {
    console.log("Opening sidebar");
    document.getElementById('sidebar').style.width = '250px';
  }

  function closeSidebar() {
    console.log("Closing sidebar");
    document.getElementById('sidebar').style.width = '0';
  }

  document.addEventListener("DOMContentLoaded", function () {
    var goToTopButton = document.getElementById("go-to-top-btn");

    window.addEventListener("scroll", function () {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            goToTopButton.style.display = "block";
        } else {
            goToTopButton.style.display = "none";
        }
    });

    goToTopButton.addEventListener("click", function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    });
  });

  $(document).ready(function() {
    const placesData = [
      {
        name: "OMNI Restaurant",
        description: "Greek comfort cuisine in a cozy setting to enjoy your meal.",
        img: "images/restaurant.jpeg",
        details: [
          { icon: "&#127760;", text: "OMNI HOTEL THESSALONIKI" },
          { icon: "&#x1F374;", text: "Greek comfort cuisine" },
          { icon: "&#10084;", text: "Cozy place to enjoy your meal" },
        ]
      },
      {
        name: "Orizontes Roof Restaurant",
        description: "Sushi and spectacular city views from our rooftop.",
        img: "images/restaurant_roof.jpeg",
        details: [
          { icon: "&#127760;", text: "OMNI HOTEL THESSALONIKI" },
          { icon: "&#x1F374;", text: "Sushi" },
          { icon: "&#10084;", text: "View of the whole city" },
        ]
      },
      {
        name: "Rooftop Bar",
        description: "A rooftop to unwind and relax with tasty cocktails.",
        img: "images/roof_bar.png",
        details: [
          { icon: "&#127760;", text: "OMNI HOTEL THESSALONIKI" },
          { icon: "&#x1F374;", text: "Relaxation Area" },
          { icon: "&#10084;", text: "Fully equipped bar" },
        ]
      },
      {
        name: "Cocktail Bar",
        description: "Radical flavor combination in the best cocktails of the town.",
        img: "images/bar.jpeg",
        details: [
          { icon: "&#127760;", text: "OMNI HOTEL THESSALONIKI" },
          { icon: "&#x1F374;", text: "Classic Bar" },
          { icon: "&#10084;", text: "Our sugnature cocktails" },
        ]
      }
    ];

    let placesHtml = '';

    placesData.forEach(place => {
      let detailsHtml = '';
      place.details.forEach(detail => {
        detailsHtml += `<p>${detail.icon} ${detail.text}</p>`;
      });

      placesHtml += `
        <div class="restaurant-section">
          <div class="restaurant-image">
            <img src="${place.img}" alt="${place.name}">
          </div>
          <div class="restaurant-details">
            <h2>${place.name}</h2>
            ${detailsHtml}
          </div>
        </div>
      `;
    });

    $('#restaurant-bar-section').html(placesHtml);
  
    let additionalContent = ''; 

    $("#load-more-btn").click(function() {
        if (additionalContent) { 
            $('#restaurant-bar-section').append(additionalContent);
            $(this).hide();
            $('#load-less-btn').show();
        } else { 
            $.ajax({
                url: "data/more-places.json",
                type: "GET",
                dataType: "json",
                success: function(data) {
                    data.places.forEach(place => {
                        let detailsHtml = '';
                        place.details.forEach(detail => {
                            detailsHtml += `<p>${detail.icon} ${detail.text}</p>`;
                        });

                        additionalContent += `
                            <div class="restaurant-section additional">
                                <div class="restaurant-image">
                                    <img src="${place.img}" alt="${place.name}">
                                </div>
                                <div class="restaurant-details">
                                    <h2>${place.name}</h2>
                                    ${detailsHtml}
                                </div>
                            </div>
                        `;
                    });

                    $('#restaurant-bar-section').append(additionalContent);
                    $('#load-more-btn').hide();
                    $('#load-less-btn').show();
                },
                error: function(xhr, status, error) {
                    console.error("An error occurred: " + error);
                }
            });
        }
    });

    $("#load-less-btn").click(function() {
        $('.additional').remove(); 
        $(this).hide();
        $('#load-more-btn').show();
        additionalContent = ''; 
    });
});
