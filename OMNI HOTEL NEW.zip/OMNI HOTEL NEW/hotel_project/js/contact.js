document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById('sidebar');
  const menuBtn = document.getElementById('menu-btn');
  const closeBtn = document.getElementById('close-btn');
  const goToTopButton = document.getElementById("go-to-top-btn");

  menuBtn.addEventListener('click', function() {
    sidebar.style.width = '250px';
  });

  closeBtn.addEventListener('click', function() {
    sidebar.style.width = '0';
  });

  window.addEventListener("scroll", function () {
    goToTopButton.style.display = (window.scrollY > 20) ? "block" : "none";
  });

  goToTopButton.addEventListener("click", function () {
    window.scrollTo({top: 0, behavior: 'smooth'});
  });
});
