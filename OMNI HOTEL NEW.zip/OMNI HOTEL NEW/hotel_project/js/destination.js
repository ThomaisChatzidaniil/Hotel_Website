function openSidebar() {
  console.log("Opening sidebar");
  document.getElementById('sidebar').style.width = '250px';
}

function closeSidebar() {
  console.log("Closing sidebar");
  document.getElementById('sidebar').style.width = '0';
}

function setupScrollToTopButton() {
  var goToTopButton = document.getElementById("go-to-top-btn");

  window.addEventListener("scroll", function () {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      goToTopButton.style.display = "block";
    } else {
      goToTopButton.style.display = "none";
    }
  });

  goToTopButton.addEventListener("click", function () {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  });
}

function loadCityAttractions(attractions) {
  const collage = document.querySelector('#image-collage'); 
  collage.innerHTML = ''; 
  attractions.forEach(attraction => {
    collage.innerHTML += `
      <a href="${attraction.url}" class="image-container">
        <img src="${attraction.image}" alt="${attraction.name}">
        <div class="image-overlay">${attraction.name}</div>
      </a>
    `;
  });
}


document.addEventListener("DOMContentLoaded", function () {
  setupScrollToTopButton();

  fetch('data/city-attraction.json')
    .then(response => response.json())
    .then(data => loadCityAttractions(data))
    .catch(error => console.error('Error loading city attractions:', error));
});
