function openSidebar() {
  console.log("Opening sidebar");
  document.getElementById('sidebar').style.width = '250px';
}

function closeSidebar() {
  console.log("Closing sidebar");
  document.getElementById('sidebar').style.width = '0';
}

document.addEventListener("DOMContentLoaded", function () {
  var goToTopButton = document.getElementById("go-to-top-btn");

  window.addEventListener("scroll", function () {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          goToTopButton.style.display = "block";
      } else {
          goToTopButton.style.display = "none";
      }
  });
});

document.addEventListener("DOMContentLoaded", function () {
  var readMoreBtn = document.getElementById("read-more-btn");
  var readLessBtn = document.getElementById("read-less-btn");
  var additionalText = document.getElementById("additional-text");

  readMoreBtn.addEventListener("click", function () {
      additionalText.style.display = "block";
      readMoreBtn.style.display = "none";
      readLessBtn.style.display = "inline-block";
  });

  readLessBtn.addEventListener("click", function () {
      additionalText.style.display = "none";
      readMoreBtn.style.display = "inline-block";
      readLessBtn.style.display = "none";
  });
});
