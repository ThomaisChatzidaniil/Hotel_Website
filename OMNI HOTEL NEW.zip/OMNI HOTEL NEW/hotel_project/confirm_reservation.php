<?php 
    $selected_room = htmlspecialchars($_GET['room_id']);
    $host = 'localhost';
    $dbname = 'my_omni_hotel';
    $username = 'root';
    $password = '';

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT cur_price FROM rooms WHERE room_id = :selected_room");
        $stmt->execute(['selected_room' => $selected_room]);
        $priceRow = $stmt->fetch(PDO::FETCH_ASSOC);
        $roomPrice = $priceRow['cur_price'];
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        $roomPrice = 0; 
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Reservation - OMNI HOTEL</title>
    <link rel="icon" href="images/omni.jpeg" type="image/jpeg">
    <link rel="stylesheet" href="css/confirm_reservation.css">
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const roomPrice = parseFloat('<?php echo $roomPrice; ?>');
            const breakfastPrice = 30;
            const vatRate = 0.24;

            function updateSummary() {
                const checkInDate = new Date('<?php echo htmlspecialchars($_GET['checkin']); ?>');
                const checkOutDate = new Date('<?php echo htmlspecialchars($_GET['checkout']); ?>');
                const daysDiff = Math.round((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));

                document.getElementById('summaryCheckIn').textContent = 'Check-in Date: ' + checkInDate.toLocaleDateString();
                document.getElementById('summaryCheckOut').textContent = 'Check-out Date: ' + checkOutDate.toLocaleDateString();
                document.getElementById('totalNights').textContent = 'Total Nights: ' + daysDiff;

                let totalPrice = roomPrice * daysDiff;
                if (document.getElementById('breakfastYes').checked) {
                    totalPrice += breakfastPrice * daysDiff;
                }
                totalPrice *= (1 + vatRate); 

                document.getElementById('totalPrice').textContent = 'Total Price: $' + totalPrice.toFixed(2);
                document.getElementById('total_price').value = totalPrice.toFixed(2);

                const cancelBy = new Date(checkInDate.getTime() - (7 * 24 * 60 * 60 * 1000));
                document.getElementById('cancelByDate').textContent = 'Free cancellation until: ' + cancelBy.toLocaleDateString();
            }

            updateSummary();
            document.querySelectorAll('input[name="breakfast"]').forEach(input => {
                input.addEventListener('change', updateSummary);
            });
        });

    </script>
</head>
<body>
<div id="top-sidebar">
    <div id="hotel-logo">
      <a href="../index.html">
        <img src="images/logo.png" alt="Hotel Logo">
      </a>
    </div>
  </div>
  <div id="sidebar">
    <div id="close-btn" onclick="closeSidebar()">&#10006;</div>
    <a href="../index.html">Home</a>
    <a href="rooms.html">Rooms & Suites</a>
    <a href="bar.html">Restaurant & Bar</a>
    <a href="event.html">Meetings & Events</a>
    <a href="destination.html">Destination</a>
    <a href="gallery.html">Gallery</a>
    <a href="contact.php">Contact</a>
    <a href="all_reviews.php">Reviews</a>
  </div>
    <h1>Confirm Your Reservation</h1>
    <div class="flex">
    <div class="flex_box">
        <form action="php/process_booking.php" method="POST">
            <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($_GET['room_id']); ?>">
            <input type="hidden" name="checkin_date" value="<?php echo htmlspecialchars($_GET['checkin']); ?>">
            <input type="hidden" name="checkout_date" value="<?php echo htmlspecialchars($_GET['checkout']); ?>">

            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" required>

            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="country">Country:</label>
            <input type="text" id="country" name="country" required>

            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" required>

            <p style="font-weight: bold;">Would you like to include breakfast?</p>
            <input type="radio" id="breakfastYes" name="breakfast" value="yes" checked>
            <label for="breakfastYes" style="font-weight: normal;">Yes</label>
            <input type="radio" id="breakfastNo" name="breakfast" value="no">
            <label for="breakfastNo" style="font-weight: normal;">No</label>
            <br><br>
            <label for="notes">Additional Comments:</label>
            <textarea id="notes" name="notes"></textarea>

            <input type="hidden" id="total_price" name="total_price">
            <br>
            <button type="submit">Submit Reservation</button>
        </form>
    </div>
    <div id="reservationSummary" class="flex_box">
        <h2>Reservation Summary</h2>
        <p id="summaryCheckIn">Check-in Date:</p>
        <p id="summaryCheckOut">Check-out Date:</p>
        <p id="totalNights">Total Nights:</p>
        <p id="totalPrice">Total Price:</p>
        <p id="cancelByDate">Free cancellation until:</p>
    </div>
</div>
<script>
  document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById('sidebar');
  const menuBtn = document.getElementById('menu-btn');
  const closeBtn = document.getElementById('close-btn');
  const goToTopButton = document.getElementById("go-to-top-btn");

  menuBtn.addEventListener('click', function() {
    sidebar.style.width = '250px';
  });

  closeBtn.addEventListener('click', function() {
    sidebar.style.width = '0';
  });

  window.addEventListener("scroll", function () {
    goToTopButton.style.display = (window.scrollY > 20) ? "block" : "none";
  });

  goToTopButton.addEventListener("click", function () {
    window.scrollTo({top: 0, behavior: 'smooth'});
  });
});

</script>
</body>
</html>
