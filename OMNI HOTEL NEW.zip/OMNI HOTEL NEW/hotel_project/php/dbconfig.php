<?php
function connectToSql(){
    $conn = mysqli_connect("localhost", "root", "");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

function createDb($sqlconn) {
    $sql = "CREATE DATABASE IF NOT EXISTS my_omni_hotel";
    if (!mysqli_query($sqlconn, $sql)) {
        die("Error creating database: " . mysqli_error($sqlconn));
    }
}

function connectToDb(){
    $conn = mysqli_connect("localhost", "root", "", "my_omni_hotel");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

function createTables($dbconn) {
    $sqlRooms = "CREATE TABLE IF NOT EXISTS rooms (
        room_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        cur_price INT,
        max_guests INT,
        image VARCHAR(255)
    );";
    if (!mysqli_query($dbconn, $sqlRooms)) {
        die("Error creating rooms table: " . mysqli_error($dbconn));
    }

    $sqlbookings = "CREATE TABLE IF NOT EXISTS bookings (
        booking_id INT AUTO_INCREMENT PRIMARY KEY,
        room_id INT,
        checkin_date DATE,
        checkout_date DATE,
        first_name VARCHAR(50), 
        last_name VARCHAR(100),
        email VARCHAR(200),
        country VARCHAR(100),
        phone INT,
        notes TEXT,
        breakfast VARCHAR(3),
        total_price INT,
        FOREIGN KEY (room_id) REFERENCES rooms(room_id)
    );";
    if (!mysqli_query($dbconn, $sqlbookings)) {
        die("Error creating bookings table: " . mysqli_error($dbconn));
    }

    $sqlContacts = "CREATE TABLE IF NOT EXISTS Contacts (
        contact_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        comment TEXT NOT NULL
    );";
    if (!mysqli_query($dbconn, $sqlContacts)) {
        die("Error creating contacts table: " . mysqli_error($dbconn));
    }

    $sqlReviews = "CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(200), 
        last_name VARCHAR(200),
        room_type VARCHAR(200),
        stars_overall INT NOT NULL,
        stars_service INT NOT NULL,
        stars_location INT NOT NULL,
        stars_rooms INT NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );";
    if (!mysqli_query($dbconn, $sqlReviews)) {
        die("Error creating reviews table: " . mysqli_error($dbconn));
    }
}

function insertSampleDataRooms($dbconn) {
    $insertRooms = $dbconn->prepare("INSERT INTO rooms (name, description, cur_price, max_guests, image) VALUES (?, ?, ?, ?, ?)");
    $roomDetails = [
        ['Deluxe Single Room', 'A luxurious single room', 200, 2, 'single.webp'],
        ['Deluxe Double Room', 'A spacious double room', 170, 1, 'double2.jpeg'],
        ['Family Suite', 'Perfect for families', 350, 5, 'family.jpg'],
        ['Suite Room', 'An exclusive suite with the best amenities', 300, 2, 'suite.jpeg']
    ];

    foreach ($roomDetails as $room) {
        $insertRooms->bind_param("ssiis", $room[0], $room[1], $room[2], $room[3], $room[4]);
        $insertRooms->execute();
    }
}

function insertSampleDataReviews($dbconn) {
    $insertReviews = $dbconn->prepare("INSERT INTO reviews (first_name, last_name, room_type, stars_overall, stars_service, stars_location, stars_rooms, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $reviewDetails = [
        ['Name1', 'Last_name1', 'Suite Room', 5, 5, 5, 5, 'One of the nicest breakfasts I have ever eaten.
        Helpful and pleasant staff.
        Cleanliness and order.'],
        ['Name2', 'Last_name2', 'Deluxe Single Room', 5, 5, 4, 5, 'The hotel was lovely and the staff very polite and the maids were kind and cleaned our room properly
        I put 4 stars on the location because I did not like that it was in the center and did not have a balcony.'],
        ['Name3', 'Last_name3', 'Deluxe Double Room', 5, 5, 5, 5, 'Excellent hotel! Spotless rooms and common areas, luxurious, with all amenities. Rich buffet, with excellent service. The staff was very polite and always willing to serve us. We will definitely prefer it again on our next trip.
        See you again!'],
        ['Name4', 'Last_name4', 'Family Suite', 3, 5, 5, 1, 'The staff is friendly and smiling trying to serve. The hotel is located in the center and has underground parking with charge as well as 4 electric chargers. Breakfast is very good. Unfortunately the rooms were not ready when we arrived. Loud noises from the installation of heating.']
    ];

    foreach ($reviewDetails as $review) {
        $insertReviews->bind_param("sssiiiis", $review[0], $review[1], $review[2], $review[3], $review[4], $review[5], $review[6], $review[7]);
        $insertReviews->execute();
    }
}
$sqlconn = connectToSql();
createDb($sqlconn);
$dbconn = connectToDb();
createTables($dbconn);

$stmt = $dbconn->prepare("SELECT * FROM rooms");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) { 
    insertSampleDataRooms($dbconn);
}

$stmt = $dbconn->prepare("SELECT * FROM reviews");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) { 
    insertSampleDataReviews($dbconn);
}

?>