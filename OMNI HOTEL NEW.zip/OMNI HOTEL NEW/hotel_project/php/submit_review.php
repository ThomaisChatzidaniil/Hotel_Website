<?php
session_start();  // Start the session at the beginning

$host = 'localhost';
$dbname = 'my_omni_hotel';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$room_type = $_POST['room_type'];
$stars_overall = (int)$_POST['stars_overall'];
$stars_service = (int)$_POST['stars_service'];
$stars_location = (int)$_POST['stars_location'];
$stars_rooms = (int)$_POST['stars_rooms'];
$description = $_POST['description'];

$stmt = $conn->prepare("SELECT * FROM bookings WHERE 
    (first_name <= ? AND last_name >= ? AND room_id = (
        SELECT room_id FROM rooms WHERE name = ?
    ))
");
$stmt->bind_param('sss', $first_name, $last_name, $room_type);
$stmt->execute();
$result = $stmt->get_result();


if ($result->num_rows > 0) {

    $stmt = $conn->prepare("INSERT INTO reviews (first_name, last_name, room_type, stars_overall, stars_service, stars_location, stars_rooms, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        $_SESSION['alert_message'] = "MySQL prepare error: " . $conn->error;
        header("Location: ../all_reviews.php");
        exit;
    }
    $stmt->bind_param("sssiiiis", $first_name, $last_name, $room_type, $stars_overall, $stars_service, $stars_location, $stars_rooms, $description);

    if ($stmt->execute()) {
        $_SESSION['alert_message'] = "Review submitted successfully!";
        header("Location: ../all_reviews.php");
        exit;
    } else {
        $_SESSION['alert_message'] = "Error submitting review: " . $stmt->error;
        header("Location: ../all_reviews.php");
        exit;
    }
} else {

    $_SESSION['alert_message'] = "Error: Reservation name $reservation_name does not exist.";
    header("Location: ../all_reviews.php");
    exit;
}
header("Location: ../all_reviews.php");

$stmt->close();
$conn->close();
?>
