<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'my_omni_hotel';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $checkinDate = $_POST['checkinDate'] ?? null;
    $checkoutDate = $_POST['checkoutDate'] ?? null;

    if (!$checkinDate || !$checkoutDate) {
        http_response_code(400); 
        echo json_encode(['error' => 'Both check-in and check-out dates are required.']);
        exit; 
    }

    $stmt = $conn->prepare("SELECT room_id, name, description, image FROM rooms WHERE room_id NOT IN (
                                SELECT room_id FROM bookings WHERE 
                                (checkin_date <= :checkout AND checkout_date >= :checkin)
                            )");
    $stmt->execute([':checkin' => $checkinDate, ':checkout' => $checkoutDate]);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$rooms) {
        http_response_code(404); 
        echo json_encode(['error' => 'No rooms available for the selected dates.']);
        exit; 
    }

    echo json_encode($rooms);

} catch (PDOException $e) {
    http_response_code(500); 
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
