<?php

include 'dbconfig.php'; // Make sure this path is correct

$servername = "localhost"; // Your server name or IP
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "my_omni_hotel"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($conn === null) {
    die("No database connection. Please check the configuration.");
}

$room_id = $_POST['room_id'];
$checkin_date = $_POST['checkin_date'];
$checkout_date = $_POST['checkout_date'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$country = $_POST['country'];
$phone = $_POST['phone'];
$notes = $_POST['notes'];
$breakfast = $_POST['breakfast'];
$total_price = $_POST['total_price'];

$stmt = $conn->prepare("INSERT INTO bookings (room_id, checkin_date, checkout_date, first_name, last_name, email, country, phone, notes, breakfast, total_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    echo "Error preparing statement: " . htmlspecialchars($conn->error);
    $conn->close();
    exit;
}
$stmt->bind_param("issssssissd", $room_id, $checkin_date, $checkout_date, $first_name, $last_name, $email, $country, $phone, $notes, $breakfast, $total_price);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    header("Location: ../book_now_dates.php?");
} else {
    $error = htmlspecialchars($stmt->error);
    header("Location: book_now_dates.php?error=$error");
}

$stmt->close();
$conn->close();


exit(); 
?>
