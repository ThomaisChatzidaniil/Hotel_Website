<?php
require "dbconfig.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['name'], $_POST['email'], $_POST['message'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $sql = "INSERT INTO contacts (name, email, comment) VALUES (?, ?, ?)";
    $dbconn = connectToDb();

    if ($stmt = $dbconn->prepare($sql)) {
        $stmt->bind_param("sss", $name, $email, $message);
        
        if ($stmt->execute()) {
            // Success message
            /* // Send email
            $to = $_POST['email'];
            $subject = "Thank You For Your Message";
            $message = "Hello " . $_POST['name'] . ",\n\nThank you for your message. We will get back to you soon.\n\nBest Regards,\nThe Omni Team";
            $headers = "From: noreply@omni.com\r\n";
            if(mail($to, $subject, $message, $headers)) {
                echo json_encode(["message" => "Form submitted successfully, email sent"]);
            } else {
                echo json_encode(["message" => "Form submitted successfully, but email sending failed"]);
            }*/
            $feedback = urlencode("Message received successfully!");
        } else {
            $feedback = urlencode("Error: Could not execute the query: " . $stmt->error);
        }
        $stmt->close();
    } else {
        $feedback = urlencode("Error in preparing statement: " . $dbconn->error);
    }
    $dbconn->close();
    
    header("Location: ../contact.php?message=$feedback");
    exit;
}
?>
