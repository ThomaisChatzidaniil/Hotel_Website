<?php 
 require "php/dbconfig.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OMNI HOTEL - Premium Stay</title>
    <link rel="stylesheet" href="css/book_now.css">
    <link rel="icon" href="images/omni.jpeg" type="image/jpeg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>
<body>
  <div id="top-sidebar">
    <div id="hotel-logo">
      <a href="../index.html">
        <img src="images/logo.png" alt="Hotel Logo">
      </a>
    </div>
    <button id="book-now-btn" onclick="window.location.href='book_now_dates.php'">BOOK NOW</button>
  </div>

  <div id="sidebar">
    <div id="close-btn" onclick="closeSidebar()">&#10006;</div>
    <a href="../index.html">Home</a>
    <a href="rooms.html">Rooms & Suites</a>
    <a href="bar.html">Restaurant & Bar</a>
    <a href="event.html">Meetings & Events</a>
    <a href="destination.html">Destination</a>
    <a href="gallery.html">Gallery</a>
    <a href="contact.php">Contact</a>
    <a href="all_reviews.php">Reviews</a>
  </div>
  <div id="menu-btn" onclick="openSidebar()">&#9776;</div>

    <div id="reservation-form">
        <h2>Book Your Stay</h2>
        <form id="bookingForm">
            <div class="date-container">
                <div class="date-picker">
                    <label for="checkinDate">Check-in:</label>
                    <input type="text" id="checkinDate" name="checkinDate" placeholder="Check-in Date" required>                </div>
                <div class="date-picker">
                    <label for="checkoutDate">Check-out:</label>
                    <input type="text" id="checkoutDate" name="checkoutDate" placeholder="Check-out Date" required>
                </div>
            </div>
                <button type="submit" onclick="validateDates()" >Submit</button>
        </form>
        <div id="validationText" style="display:none;"></div>
        <div id="availableRooms" style="display:none;"></div>
    </div>

    <button id="go-to-top-btn">&#8679;</button>
    <script src="js/book_now.js"></script>
</body>

  <div id="footer">
    <div class="footer-menu">
      <a href="../index.html">Home</a>
      <a href="rooms.html">Rooms & Suites</a>
      <a href="bar.html">Restaurant & Bar</a>
      <a href="event.html">Meetings & Events</a>
      <a href="destination.html">Destination</a>
      <a href="gallery.html">Gallery</a>
      <a href="contact.php">Contact</a>
      <a href="all_reviews.php">Reviews</a>
    </div>
  
    <div class="contact-details">
      <p>51 Mitropoleos Av.,</p>
      <p>Thessaloniki 546 24, Greece</p>
      <p>T: +30 2310 999 990</p>
      <p>F: +30 2310 999 999</p>
      <p>E: info@OmniHotel.gr</p>
    </div>
  
    <div class="social-icons">
      <a href="https://www.facebook.com/" class="facebook" target="_blank"><img src="images/R.png" alt=""></a>
      <a href="https://www.instagram.com/?hl=en" class="instagram" target="_blank"><img src="images/unnamed.png" alt=""></a>
    </div>
  
    <p class="copyright-text">© 2023 OMNI HOTEL Premium Stay. All rights reserved.</p>
  </div>
  </html>
