<?php
session_start();
require "php/dbconfig.php";

$host = 'localhost';
$dbname = 'my_omni_hotel';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sort = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc'; 

switch ($sort) {
    case 'most_stars':
        $orderBy = "stars_overall DESC";
        break;
    case 'least_stars':
        $orderBy = "stars_overall ASC";
        break;
    case 'date_asc':
        $orderBy = "created_at ASC";
        break;
    default:
        $orderBy = "created_at DESC";
}

$query = "SELECT * FROM reviews ORDER BY $orderBy";
$result = $conn->query($query);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/all_reviews.css" type="text/css">
  <link rel="icon" href="images/omni.jpeg" type="image/jpeg">
  <title>OMNI HOTEL - Premium Stay</title>
 <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>


<body>
  <div id="top-sidebar">
    <div id="hotel-logo">
      <a href="../index.html">
        <img src="images/logo.png" alt="Hotel Logo">
      </a>
    </div>
    <button id="book-now-btn" onclick="window.location.href='book_now_dates.php'">BOOK NOW</button>
  </div>

  <div id="sidebar">
    <div id="close-btn" onclick="closeSidebar()">&#10006;</div>
    <a href="../index.html">Home</a>
    <a href="rooms.html">Rooms & Suites</a>
    <a href="bar.html">Restaurant & Bar</a>
    <a href="event.html">Meetings & Events</a>
    <a href="destination.html">Destination</a>
    <a href="gallery.html">Gallery</a>
    <a href="contact.php">Contact</a>
    <a href="all_reviews.php">Reviews</a>
  </div>
  <div id="menu-btn" onclick="openSidebar()">&#9776;</div>
  <main>
    <section class="content-header" style="  background-color: #f5f5dc;">
      <h1>All Reviews</h1>
      <nav>
        <a href="reviews.php">Make Your Review</a> |
        <a href="?sort=most_stars">Sort by Most Stars</a> |
        <a href="?sort=least_stars">Sort by Least Stars</a> |
        <a href="?sort=date_desc">Sort by Newest</a> |
        <a href="?sort=date_asc">Sort by Oldest</a>
      </nav>
    </section>

    <section class="reviews-container">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <article class="review-card">
                    <h3><?= htmlspecialchars($row['first_name']) ?> <?= htmlspecialchars($row['last_name']) ?></h3>
                    <p class="timestamp"><?= $row['created_at'] ?>
                    <br><?= htmlspecialchars($row['room_type']) ?>
                    </p>
                    <div class="stars">
                        <strong><?= $row['stars_overall'] ?> Stars</strong>
                    </div>
                    <p class="description"><?= htmlspecialchars(($row['description'])) ?></p>
                    <button onclick="toggleDetails(this)">Show More</button>
                    <div class="additional-info" id="additional-info"style="display:none;">
                        <p>Service: <?= $row['stars_service'] ?> stars</p>
                        <p>Location: <?= $row['stars_location'] ?> stars</p>
                        <p>Rooms: <?= $row['stars_rooms'] ?> stars</p>
                    </div>
                </article>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No reviews found.</p>
        <?php endif; ?>
    </section>
  </main>

  <script src="js/all_reviews.js"></script>

<div id="footer">
  <div class="footer-menu">
    <a href="../index.html">Home</a>
    <a href="rooms.html">Rooms & Suites</a>
    <a href="bar.html">Restaurant & Bar</a>
    <a href="event.html">Meetings & Events</a>
    <a href="destination.html">Destination</a>
    <a href="gallery.html">Gallery</a>
    <a href="contact.php">Contact</a>
    <a href="all_reviews.php">Reviews</a>
  </div>

  <div class="contact-details">
    <p>51 Mitropoleos Av.,</p>
    <p>Thessaloniki 546 24, Greece</p>
    <p>T: +30 2310 999 990</p>
    <p>F: +30 2310 999 999</p>
    <p>E: info@OmniHotel.gr</p>
  </div>

  <div class="social-icons">
    <a href="https://www.facebook.com/" class="facebook" target="_blank"><img src="images/R.png" alt=""></a>
    <a href="https://www.instagram.com/?hl=en" class="instagram" target="_blank"><img src="images/unnamed.png" alt=""></a>
  </div>

  <p class="copyright-text">© 2023 OMNI HOTEL Premium Stay. All rights reserved.</p>
</div>
</body>
</html>