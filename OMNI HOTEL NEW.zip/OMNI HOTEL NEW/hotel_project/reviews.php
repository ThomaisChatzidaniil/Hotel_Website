<?php 
 require "php/dbconfig.php"
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Reservation - OMNI HOTEL</title>
    <link rel="icon" href="images/omni.jpeg" type="image/jpeg">
    <link rel="stylesheet" href="css/reviews.css">
</head>
<body>
<div id="top-sidebar">
    <div id="hotel-logo">
      <a href="../index.html">
        <img src="images/logo.png" alt="Hotel Logo">
      </a>
    </div>
  </div>
  <div id="sidebar">
    <div id="close-btn" onclick="closeSidebar()">&#10006;</div>
    <a href="../index.html">Home</a>
    <a href="rooms.html">Rooms & Suites</a>
    <a href="bar.html">Restaurant & Bar</a>
    <a href="event.html">Meetings & Events</a>
    <a href="destination.html">Destination</a>
    <a href="gallery.html">Gallery</a>
    <a href="contact.php">Contact</a>
    <a href="all_reviews.php">Reviews</a>
  </div>
  <div id="menu-btn" onclick="openSidebar()">&#9776;</div>
 <div id="section">
<h1>Submit Your Review</h1>
<div id="form">
<form action="php/submit_review.php" method="POST">
    <label for="first_name">First Name:</label>
    <input type="text" id="first_name" name="first_name" required><br>
    <br>
    <label for="last_name">Last Name:</label>
    <input type="text" id="last_name" name="last_name" required><br>
    <br>
    <label for="stars_overall">Overall Rating:</label>
    <input type="number" id="stars_overall" name="stars_overall" min="1" max="5" required><br>
    <br>
    <label for="stars_service">Service Rating:</label>
    <input type="number" id="stars_service" name="stars_service" min="1" max="5" required><br>
    <br>
    <label for="stars_location">Location Rating:</label>
    <input type="number" id="stars_location" name="stars_location" min="1" max="5" required><br>
    <br>
    <label for="stars_rooms">Room Rating:</label>
    <input type="number" id="stars_rooms" name="stars_rooms" min="1" max="5" required><br>
    <br>
    <p style="font-weight: bold;">Select the room type of your reservation?</p>
            <input type="radio" id="Suite_Room" name="room_type" value="Suite Room" checked>
            <label for="Suite_Room" style="font-weight: normal;">Suite Room</label>
            <input type="radio" id="Deluxe_Single_Room" name="room_type" value="Deluxe Single Room">
            <label for="Deluxe_Single_Room" style="font-weight: normal;">Deluxe Single Room</label>
            <input type="radio" id="Deluxe_Double_Room" name="room_type" value="Deluxe Double Room">
            <label for="Deluxe_Double_Room" style="font-weight: normal;">Deluxe Double Room</label>
            <input type="radio" id="Family_Suite" name="room_type" value="Family Suite">
            <label for="Family_Suite" style="font-weight: normal;">Family Suite</label>
            <br> <br> <br>
    <label for="description">Description:</label>
    <textarea id="description" name="description"></textarea><br>
    <br>
    <button type="submit">Submit Review</button>
</form>
</div>
<script>
  document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById('sidebar');
  const menuBtn = document.getElementById('menu-btn');
  const closeBtn = document.getElementById('close-btn');
  const goToTopButton = document.getElementById("go-to-top-btn");

  menuBtn.addEventListener('click', function() {
    sidebar.style.width = '250px';
  });

  closeBtn.addEventListener('click', function() {
    sidebar.style.width = '0';
  });

  window.addEventListener("scroll", function () {
    goToTopButton.style.display = (window.scrollY > 20) ? "block" : "none";
  });

  goToTopButton.addEventListener("click", function () {
    window.scrollTo({top: 0, behavior: 'smooth'});
  });
});

</script>
</body>
</html>
