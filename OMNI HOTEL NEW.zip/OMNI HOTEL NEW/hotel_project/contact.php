<?php
  require "php/dbconfig.php"
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/contact.css">
  <link rel="icon" href="images/omni.jpeg" type="image/jpeg">
  <title>OMNI HOTEL - Premium Stay</title>
</head>

<body>
  <div id="top-sidebar">
    <div id="hotel-logo">
      <a href="../index.html">
        <img src="images/logo.png" alt="Hotel Logo">
      </a>
    </div>
    <button id="book-now-btn" onclick="window.location.href='book_now_dates.php'">BOOK NOW</button>
  </div>

  <div id="sidebar">
    <div id="close-btn" onclick="closeSidebar()">&#10006;</div>
      <a href="../index.html">Home</a>
      <a href="rooms.html">Rooms & Suites</a>
      <a href="bar.html">Restaurant & Bar</a>
      <a href="event.html">Meetings & Events</a>
      <a href="destination.html">Destination</a>
      <a href="gallery.html">Gallery</a>
      <a href="contact.php">Contact</a>
      <a href="all_reviews.php">Reviews</a>
  </div>
  <div id="menu-btn" onclick="openSidebar()">&#9776;</div>

  <div id="contact-header">
    <h2>CONTACT US</h2>
    <div id="contact-info">
      <div id="contact-text">
        <h3>CONTACT</h3>
        <p>51 Mitropoleos Av.,
          Thessaloniki 546 24, Greece</p>
        <p>Phone: +30 2310 999 990</p>
        <p>Email: info@OmniHotel.gr</p>
        <p>Do not hesitate to send us your questions and comments</p>
      </div>
      <div id="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3027.9221782483037!2d22.94068387589853!3d40.6315981714059!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a839063f6870e7%3A0x2ab74652816c85a7!2zzpzOt8-Ez4HOv8-Az4zOu861z4nPgiA2NS01MSwgzpjOtc-Dz4POsc67zr_Ovc6vzrrOtyA1NDYgMjM!5e0!3m2!1sel!2sgr!4v1702043410745!5m2!1sel!2sgr" width="800" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
    </div>
  </div>
  <div id="contact-form-root"></div>

  <div id="contact-form">
    <h2>SEND US YOUR MESSAGES</h2>
    <form id="message-form" action="php/submit_contact.php" method="post">
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" onfocus="clearPlaceholder(this)" required>
      </div> 
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" onfocus="clearPlaceholder(this)" required>
      </div>
      <div class="form-group message-group">
        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="4" placeholder="Enter your message" onfocus="clearPlaceholder(this)" required></textarea>
      </div>
      <button type="submit" id="submit-button">SEND</button>
    </form>
  </div>
<?php
  if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);  
    echo "<script type='text/javascript'>alert('$message');</script>";
}

?>
  <button id="go-to-top-btn">&#8679;</button>

  <script src="js/contact.js"></script>

  <div id="footer">
    <div class="footer-menu">
      <a href="../index.html">Home</a>
      <a href="rooms.html">Rooms & Suites</a>
      <a href="bar.html">Restaurant & Bar</a>
      <a href="event.html">Meetings & Events</a>
      <a href="destination.html">Destination</a>
      <a href="gallery.html">Gallery</a>
      <a href="contact.php">Contact</a>
      <a href="all_reviews.php">Reviews</a>
    </div>

    <div class="contact-details">
      <p>51 Mitropoleos Av.,</p>
      <p>Thessaloniki 546 24, Greece</p>
      <p>T: +30 2310 999 990</p>
      <p>F: +30 2310 999 999</p>
      <p>E: info@OmniHotel.gr</p>
    </div>

    <div class="social-icons">
      <a href="https://www.facebook.com/" class="facebook" target="_blank"><img src="images/R.png" alt=""></a>
      <a href="https://www.instagram.com/?hl=en" class="instagram" target="_blank"><img src="images/unnamed.png" alt=""></a>
    </div>

    <p class="copyright-text">© 2023 OMNI HOTEL Premium Stay. All rights reserved.</p>
  </div>

</body>

</html>
